token = '1493436800:AAF1Eult9X13lyLQGGdScK63MbGOJyGqGbk'

keys = {
    'евро': 'EUR',
    'доллар': 'ЮэСДэ',
    'рубль': 'RUB',
}
